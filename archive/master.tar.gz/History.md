
0.0.6 / 2014-09-22
==================

 * secure SSH and remove root access programmatically
 * remove firewall stuff for now
